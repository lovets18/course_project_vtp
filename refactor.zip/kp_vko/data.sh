#!/bin/bash

TempDirectory=/tmp/GenTargets
DirectoryTargets="$TempDirectory/Targets"
DestroyDirectory="$TempDirectory/Destroy"
DirectoryComm="$TempDirectory/Comm"
DirectoryCommLog="$TempDirectory/CommLog"
LogFile=$TempDirectory/GenTargets.log

MaxRLS=3
MaxZRDN=3
MaxSPRO=1

declare -a RLS  # x y a r fov
#1
RLS[0+5*0]=5500 # Координата X
RLS[1+5*0]=3750	# Координата Y
RLS[2+5*0]=270	# Азимут
RLS[3+5*0]=3000 # Дальность действия
RLS[4+5*0]=120	  # Угол обзора	
#2
RLS[0+5*1]=7500
RLS[1+5*1]=3500
RLS[2+5*1]=315
RLS[3+5*1]=400
RLS[4+5*1]=200
#3
RLS[0+5*2]=8000
RLS[1+5*2]=3500
RLS[2+5*2]=45
RLS[3+5*2]=7000
RLS[4+5*2]=90

declare -a ZRDN  # x y r
#1
ZRDN[0+4*0]=3200
ZRDN[1+4*0]=3000
ZRDN[2+4*0]=600
ZRDN[3+4*0]=20
#1
ZRDN[0+4*1]=2250
ZRDN[1+4*1]=3200
ZRDN[2+4*1]=400
ZRDN[3+4*1]=20
#1
ZRDN[0+4*2]=2700
ZRDN[1+4*2]=3250
ZRDN[2+4*2]=550
ZRDN[3+4*2]=20

declare -a SPRO  # x y r
#1
SPRO[0+4*0]=9500
SPRO[1+4*0]=3000
SPRO[2+4*0]=1100
SPRO[3+4*0]=10