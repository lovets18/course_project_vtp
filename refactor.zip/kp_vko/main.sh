#!/bin/bash

source "methods.sh" 2>/dev/null 
res=$? 

if [[ $res != 0 ]]
then
  echo -e "Невозможен запуск в интерпретаторе, отличном от BASH"
  exit 1
fi

CheckStart # Проверка возможности запуска

# Запуск РЛС
date=`date +'%F %T'`
bash ./rls.sh 0 &
# bash ./subsystems.sh 0 &
rls_pid=$!; echo -e "${UWhite}$date${NOCOLOR} |  Запуск РЛС PID=$rls_pid"
ms=`echo -e "Запуск РЛС PID=$rls_pid"`
date=`date +'%F %T'`
#write_to_db system_db.db log_table "message, date" "'$ms', '$date'"
sleep 0.1

# Запуск ЗРДН
date=`date +'%F %T'`
bash ./zrdn.sh 1 &
# bash ./subsystems.sh 1 &
zrdn_pid=$!; echo -e "${UWhite}$date${NOCOLOR} |  Запуск ЗРДН PID=$zrdn_pid"
ms=`echo -e "Запуск ЗРДН PID=$zrdn_pid"`
#write_to_db system_db.db log_table "message, date" "'$ms', '$date'"
sleep 0.1

# Запуск СПРО
date=`date +'%F %T'`
bash ./spro.sh 2 &
# bash ./subsystems.sh 2 &
spro_pid=$!; echo -e "${UWhite}$date${NOCOLOR} |  Запуск СПРО PID=$spro_pid"
ms=`echo -e "Запуск СПРО PID=$spro_pid"`
#write_to_db system_db.db log_table "message, date" "'$ms', '$date'"
sleep 0.1

bash ./command_post.sh
date=`date +'%F %T'`
echo -e "${UWhite}$date${NOCOLOR} |  Завершение работы подсистемы РЛС";  disown $rls_pid 2>/dev/null; kill -9 $rls_pid 2>/dev/null;
ms=`echo -e "Завершение работы подсистемы РЛС"`
write_to_db system_db.db log_table "message, date" "'$ms', '$date'" `
echo -e "${UWhite}$date${NOCOLOR} |  Завершение работы подсистемы ЗРДН"; disown $zrdn_pid 2>/dev/null;  kill -9 $zrdn_pid 2>/dev/null;
ms=`echo -e "Завершение работы подсистемы ЗРДН"`
#write_to_db system_db.db log_table "message, date" "'$ms', '$date'"`
echo -e "${UWhite}$date${NOCOLOR} |  Завершение работы подсистемы СПРО"; disown $spro_pid 2>/dev/null;  kill -9 $spro_pid 2>/dev/null;
ms=`echo -e "Завершение работы подсистемы СПРО"`
#write_to_db system_db.db log_table "message, date" "'$ms', '$date'"
