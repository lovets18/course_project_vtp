#!/bin/bash


BLUE='\033[0;34m'
WHITE='\033[0;37m' 
RED='\033[0;31m'  
NOCOLOR='\033[0m'

Color_Off='\033[0m'       # Text Reset

# Regular Colors
Black='\033[0;30m'        # Black
Red='\033[0;31m'          # Red
Green='\033[0;32m'        # Green
Yellow='\033[0;33m'       # Yellow
Blue='\033[0;34m'         # Blue
Purple='\033[0;35m'       # Purple
Cyan='\033[0;36m'         # Cyan
White='\033[0;37m'        # White

# Bold
BBlack='\033[1;30m'       # Black
BRed='\033[1;31m'         # Red
BGreen='\033[1;32m'       # Green
BYellow='\033[1;33m'      # Yellow
BBlue='\033[1;34m'        # Blue
BPurple='\033[1;35m'      # Purple
BCyan='\033[1;36m'        # Cyan
BWhite='\033[1;37m'       # White

# Underline
UBlack='\033[4;30m'       # Black
URed='\033[4;31m'         # Red
UGreen='\033[4;32m'       # Green
UYellow='\033[4;33m'      # Yellow
UBlue='\033[4;34m'        # Blue
UPurple='\033[4;35m'      # Purple
UCyan='\033[4;36m'        # Cyan
UWhite='\033[4;37m'       # White

# Background
On_Black='\033[40m'       # Black
On_Red='\033[41m'         # Red
On_Green='\033[42m'       # Green
On_Yellow='\033[43m'      # Yellow
On_Blue='\033[44m'        # Blue
On_Purple='\033[45m'      # Purple
On_Cyan='\033[46m'        # Cyan
On_White='\033[47m'       # White

# High Intensity
IBlack='\033[0;90m'       # Black
IRed='\033[0;91m'         # Red
IGreen='\033[0;92m'       # Green
IYellow='\033[0;93m'      # Yellow
IBlue='\033[0;94m'        # Blue
IPurple='\033[0;95m'      # Purple
ICyan='\033[0;96m'        # Cyan
IWhite='\033[0;97m'       # White

# Bold High Intensity
BIBlack='\033[1;90m'      # Black
BIRed='\033[1;91m'        # Red
BIGreen='\033[1;92m'      # Green
BIYellow='\033[1;93m'     # Yellow
BIBlue='\033[1;94m'       # Blue
BIPurple='\033[1;95m'     # Purple
BICyan='\033[1;96m'       # Cyan
BIWhite='\033[1;97m'      # White

# High Intensity backgrounds
On_IBlack='\033[0;100m'   # Black
On_IRed='\033[0;101m'     # Red
On_IGreen='\033[0;102m'   # Green
On_IYellow='\033[0;103m'  # Yellow
On_IBlue='\033[0;104m'    # Blue
On_IPurple='\033[0;105m'  # Purple
On_ICyan='\033[0;106m'    # Cyan
On_IWhite='\033[0;107m'   # White


function CheckStart			# Функция проверки возможности запуска
{
	if [[ $EUID -eq 0 ]]	# Проверка на то, что запускает не админ
	then
		echo -e "Невозможен запуск с правами администратора"
		exit 1
	fi

	OS=`uname -s`
	if [[ $OS != "Linux" ]]	 # Проверка ОС
	then
	  echo -e "Невозможен запуск в ОС, отличной от Linux"
	  exit 1
	fi

	t1=`echo -e $BASH | grep -o bash` 
	res=$?
	if [ $res != 0 ]
	then
	  echo -e "Невозможен запуск в интерпретаторе, отличном от BASH"
	  exit 1
	fi
}

sigint_handler() { echo -e "";echo -e "Завершение работы системы $SubsystemType" ; exit 0;} 

function GetTargets				# Функция получения списка целей
{
	Targets=`ls -tr $DirectoryTargets 2>/dev/null | tail -n 30`	# Сортированные данные целей
	result=$?
	if (( $result != 0 ))
	then
		echo -e "Система не запущена!"
		exit 0
	fi
}

returnIdx=0;
function NewTarget			# Функция проверки на новизну цели (Если цель новая, возвращается -1, иначе возвращается индекс элемента)
{
  sizeofElem="$1"			# Количество характеристик одной цели
  idcurr="$2"					# Идентификатор цели

  ((countofElem=${#TargetsId[@]}/sizeofElem)); # TargetsId - это массив целей, sizeofElem - количество характеристик одной цели
  returnIdx=-1
  i=0
  while (( "$i" < "$countofElem" ))
  do
    if [[ "${TargetsId[0+$sizeofElem*$i]}" == "$idcurr" ]]
    then
      returnIdx=$i
      break;
    fi
    let i+=1
  done
}

function ClassifyTarget			# Функция классификации цели по скорости
{
  #0-ББ БР 1-Самолеты 2-Крылатые ракеты
  	speedX=$1		# Скорость по Х
	speedY=$2		# скорость по Y
	speed=$(echo -e "sqrt ( (($speedX*$speedX+$speedY*$speedY)) )" | bc)		# Определяем скорость как гипотенузу

	if ((( $speed > 50 )) && (( $speed < 250 )))				# Если скорость 50-249, то Самолёт
  then
    return 1
  fi

	if ((( $speed > 249 )) && (( $speed < 1000 )))			# Если скорость 250-999, то К.ракета
  then
    return 2
  fi

  if ((( $speed > 7999 )) && (( $speed < 10000 )))		# Если скорость 8000-9999, то ББ БР
  then
    return 0
  fi

  return 100
}


hbspro=0
hbzrdn=0
hbrls=0

function PulseInit	# Метод инициализации пульса систем (для контроля жизни) 
{
	type="$1"
	filename=$DirectoryComm/$type
	echo -e "0" >$filename
	case $type in
  "rls")
		hbrls=0
    ;;
  "spro")
		hbspro=0
    ;;
  "zrdn")
		hbzrdn=0
  esac
}

function Pulse	# Метод контроля пульса (для увеличения пульса на 1)
{
	type="$1"

	case $type in
  "rls")
		let hbrls+=1
		echo -e "$hbrls" >$filename
    ;;
  "spro")
 		let hbspro+=1
		echo -e "$hbspro" >$filename
    ;;
  "zrdn")
		let hbzrdn+=1
		echo -e "$hbzrdn" >$filename
  esac
}

function RandomSleep
{
	rand=$((RANDOM%5+5))		# Число от 5 до 9
	sltime=$(echo -e "$rand/10" | bc -l);
	sleep 0.8
}






function write_to_db 
{ 
	# Параметры функции: 
	# $1 - название базы данных 
	# $2 - название таблицы 
	# $3 - столбцы, в которые необходимо записать информацию, разделенные запятыми 
	# $4 - значения для записи, разделенные запятыми и обернутые в кавычки  
	# Строим SQL-запрос: 
	local query="INSERT INTO $2 ($3) VALUES ($4);"  
	# Запускаем SQLite и выполняем запрос: 
	sqlite3 $1 "$query" 
}











# Функция установки параметров системы
function SetSystemParametrs
{
	local cType=$1; 
	case $cType in
	0)	# РЛС
		SubsystemType="РЛС"
		SubsystemLog="rls"
		NumberOfSystem=$MaxRLS
		SubsystemCanShoot=(0 0 0) #0-ББ БР 1-Самолеты 2-Крылатые ракеты
		;;
	1)	# ЗРДН
		SubsystemType="ЗРДН"
		SubsystemLog="zrdn"
		NumberOfSystem=$MaxZRDN
		SubsystemCanShoot=(0 1 1) #0-ББ БР 1-Самолеты 2-Крылатые ракеты
		;;
	2)	# СПРО
		SubsystemType="СПРО"
		SubsystemLog="spro"
		NumberOfSystem=$MaxSPRO
		SubsystemCanShoot=(1 0 0) #0-ББ БР 1-Самолеты 2-Крылатые ракеты
		;;
  esac
}


function CheckSectorCoverage()
{
	local i=$1
	local X=$2
	local Y=$3

	((x1=-1*${RLS[0+5*$i]}+$X))	# Получение координаты X относительно РЛС
	((y1=-1*${RLS[1+5*$i]}+$Y)) # Получение координаты Y относительно РЛС

	local r1=$(echo -e "sqrt ( (($x1*$x1+$y1*$y1)) )" | bc) # Высчитываем расстояние цели до РЛС

	if (( $r1 <= ${RLS[3+5*$i]} ))
	then
	  local fi=$(echo -e | awk " { x=atan2($y1,$x1)*180/3.14; print x}"); fi=(${fi/\.*}); # Рассчитываем угол от -pi до pi для цели
	  if [ "$fi" -lt "0" ]
	  then
	   	((fi=360+$fi))	   # Если меньше нуля, то добавляем 360 градусов
	  fi

 	  ((fimax=${RLS[2+5*$i]}+${RLS[4+5*$i]}/2-90)); # Получаем углы сектора обзора
	  ((fimin=${RLS[2+5*$i]}-${RLS[4+5*$i]}/2-90));
 	  if (( $fi <= $fimax )) && (( $fi >= $fimin ))	# Если угол направления цели попадает в сектор
	  then
	   	return 1 # Возвращаем 1, если цель попала в сектор
	  fi
	fi
	return 0	# Возвращаем 0, если цель не попала в сектор
}

function CheckCirclerCoverage()
{
	local i=$1
	local X=$2
	local Y=$3
	local typeofvko=$4

	if (( typeofvko == 1 )) # Проверяем тип, если 1, то СПРО, иначе ЗРДН
	then
		((x1=-1*${SPRO[0+3*$i]}+$X))  # Получение координаты X относительно СПРО
		((y1=-1*${SPRO[1+3*$i]}+$Y))  # Получение координаты Y относительно СПРО
	else
		((x1=-1*${ZRDN[0+3*$i]}+$X))  # Получение координаты X относительно ЗРДН
		((y1=-1*${ZRDN[1+3*$i]}+$Y))  # Получение координаты Y относительно ЗРДН
	fi
	
	local r1=$(echo -e "sqrt ( (($x1*$x1+$y1*$y1)) )" | bc) # Высчитываем расстояние цели до РЛС

	if (( typeofvko == 1 )) # Проверяем тип, если 1, то СПРО, иначе ЗРДН
	then
		if [ "$r1" -le "${SPRO[2+3*$i]}" ]  # Если расстояние меньше радиуса обзора
		then
		  return 1
		fi
	else
		# echo -e $typeofvko
		if [ "$r1" -le "${ZRDN[2+3*$i]}" ]  # Если расстояние меньше радиуса обзора
		then
		  return 1
		fi
	fi
	return 0  # Возвращаем 0, если цель не попала в обзор
}

# Проверка нахождения цели в зоне действия системы
function CheckCoverage
{
	local type="$1"	# Тип системы
	local no=$2 		# Номер объекта системы
	local Xm=$3			# Координата Х цели
	local Ym=$4 		# Координата Y цели

  ((X=$Xm/1000))
#   echo -e $type
	((Y=$Ym/1000))

	case $type in
  "РЛС")
    CheckSectorCoverage $no $X $Y
	  spotted=$? # Результат (попала цель в обзор или нет)
	  return $spotted
    ;;
  "СПРО")
   	CheckCirclerCoverage $no $X $Y 1
	  spotted=$? # Результат (попала цель в обзор или нет)
	  return $spotted
    ;;
 	"ЗРДН")
    CheckCirclerCoverage $no $X $Y 2
	  spotted=$? # Результат (попала цель в обзор или нет)
	  return $spotted
  esac	
}