#!/bin/bash

#-------------- Секция инициализации --------------

SYSTEMS=("rls" "zrdn" "spro" "kp")		# Массив с именами файлов систем
SYSTEMSDESCR=("РЛС" "ЗРДН" "СПРО")		# Массив систем для вывода в логи
HBVARS=("-1" "-1" "-1")								# Массив для хранения значений пульса систем
LOGLINES=("0" "0" "0")								# Массив для хранения количества выведенных строк из лог файлов для систем
COUNTLINES=("-1" "-1" "-1" "-1")			# Массив для хранения количества строк в логах, которые были записаны за 30 минут

source "data.sh"
source "methods.sh"

SubsystemType="КП"
SubsystemLog="KP"
NumberOfSystem=0
SubsystemCanShoot=(0 0 0) # 0-ББ БР 1-Самолеты 2-Крылатые ракеты

commfile="$DirectoryCommLog/kp.log"
CheckStart

trap sigint_handler 2 		# Отлов сигнала остановки процесса. Если сигнал пойман, то вызывается функция ...

date=`date +'%F %T'`
echo -e "${UWhite}$date${NOCOLOR} |  Система $SubsystemType успешно инициализирована!"
echo -e "${UWhite}$date${NOCOLOR} |  Система $SubsystemType успешно инициализирована!" >>$commfile

sltime=0;

#-------------- Секция работы КП --------------

while :
do
	sleep 1
	let sltime+=1

	#-------------- Секция вывода логов --------------

  if (( sltime%2 == 0))		# Если счётчик кратен 2м, то ...
	then
		i=0
		while (( $i < 3 ))		# Цикл по подсистемам
		do
			lines=`wc -l "$DirectoryCommLog/${SYSTEMS[$i]}.log" 2>/dev/null`; res=$? 	# Получаем строку с количеством строк в лог файле и с названием этого файла
			if (( res == 0 ))																													# Если количество строк удалось получить, то ...
			then
				count=($lines)																													# Получаем массив из строки
				count=${count[0]}																												# Получаем первый элемент массива (количество строк в лог файле)
				((LinesToDisplay=$count-${LOGLINES[$i]}))																# Получаем количество строк, которое нужно вывести
				LOGLINES[$i]=$count																											# Определяем количество уже выведенных строк
				if (( $LinesToDisplay > 0))																							# Если количество строк строк, которое нужно вывести, больше нуля, то ...
				then
					readedfile=`tail -n $LinesToDisplay $DirectoryCommLog/${SYSTEMS[$i]}.log 2>/dev/null`;result=$?		# Считываем строки, которые нужно вывести
					if (( $result == 0 ))																									# Если удалось считать, то ...
					then
						echo -e "$readedfile" | base64 -d																			# выводим декодированные строки
						echo -e "$readedfile" | base64 -d >> $commfile
					fi
				fi
			fi
			let i+=1
		done
	fi

	#-------------- Секция мониторинга состояния подсистем --------------

  if (( sltime%30 == 0))				# Если счётчик кратен 2м, то ...
	then
		i=0
		while (( $i < 3 ))					# Цикл по подсистемам
		do
			readedfile=`tail $DirectoryComm/${SYSTEMS[$i]} 2>/dev/null`; result=$?	# Получаем значение пульса из файла
			date=`date +'%F %T'`
			if (( $result == 0 ))
			then
				if (( ${HBVARS[$i]} == $readedfile))				# Если значение пульса не изменилось по сравнению с предыдущим, то ...
				then
					echo -e "  ${UWhite}$date${NOCOLOR} |  Система ${SYSTEMSDESCR[$i]} зависла"
					echo -e "  ${UWhite}$date${NOCOLOR} |  Система ${SYSTEMSDESCR[$i]} зависла" >>$commfile
				fi
				HBVARS[$i]=$readedfile
			else
				echo -e "  ${UWhite}$date${NOCOLOR} |  Ошибка доступа к cиcтеме ${SYSTEMSDESCR[$i]}"
				echo -e "  ${UWhite}$date${NOCOLOR} |  Ошибка доступа к cиcтеме ${SYSTEMSDESCR[$i]}" >>$commfile
			fi
			let i+=1
		done
	fi

	#-------------- Секция контроля логов --------------

  if (( sltime%2000 == 0)) 						# Раз в 200 тактов сохраняем количество строк за 200 тактов
	then
		i=0
		while (( $i < 4 ))
		do
			lines=`wc -l "$DirectoryCommLog/${SYSTEMS[$i]}.log" 2>/dev/null`; res=$?		# Получаем количество строк в лог файле
			if (( res == 0 ))																														# Если количество строк удалось получить, то
			then
				count=($lines)																														# Получаем массив ищ строки с информацией о количестве строк
				count=${count[0]}																													# Получаем первое число из массива
				COUNTLINES[$i]=$count																											# Переприсваиваем количество строк
			fi
			let i+=1
		done
	fi
	if (( sltime%3800 == 0 ))   # Раз в 380 тактов удаляем количество строк за 200 тактов
	then
		i=0
		while (( $i < 4 ))	# Цикл по всем системам
		do
			if ((${COUNTLINES[$i]}>0))
			then
				date=`date +'%F %T'`
				echo -e "${UWhite}$date${NOCOLOR} |  Удаление ${COUNTLINES[$i]} первых строк из файла ${SYSTEMS[$i]}.log"
				sed -i "1,${COUNTLINES[$i]}d" "/tmp/GenTargets/CommLog/${SYSTEMS[$i]}.log"
			fi
			let i+=1
		done
	fi
done
